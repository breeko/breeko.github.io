# A Free Open-Source iPad Calculator and Why Your App Won't Make You Any Money

After an unsatisfactory selection of free (free to download, no ads/tracking or in app purchases) iPad calculator apps, I wrote one myself.

The app store won't make you any money. So why do people keep trying to monetize even the most basic apps? I decided to write simple free open-source apps for everyone, starting with a calculator.

After an unsatisfactory selection of free (free to download, no ads/tracking or in app purchases) iPad calculator apps, I wrote and open sourced my own using React Native. The design is heavily inspired by [Google’s calculator app for Android](https://play.google.com/store/apps/details?id=com.google.android.calculator&hl=en). The iOS and iPad app store in particular is spammy and unprofitable for developers due to saturation and insurmountable app store economics. Available for [iOS](https://itunes.apple.com/us/app/opencalc/id1403173317?mt=8) and [Android](https://play.google.com/store/apps/details?id=com.twelve31labs.opencalc). Full source is available at [GitHub](https://github.com/breeko/OpenCalc).

![](https://cdn-images-1.medium.com/max/800/1*vQmqq8eQZBbRxkDPvf49_g.png)

OpenCalc on iPad

This post will discuss some of my thoughts on the mobile app market. A more detailed technical post on OpenCalc will be in a separate post.

### Lack of iPad Apps

I’ve always been surprised at the lack of quality iPad apps. I haven’t done an exhaustive review, but my impression is that many apps that should be supported on iPad are not. It’s incredible to think that one of the most popular apps, WhatsApp, is not available. Also, Instagram is only available as a scaled up iPhone version. Given that XCode had [autolayout](https://developer.apple.com/library/archive/documentation/UserExperience/Conceptual/AutolayoutPG/index.html) for some time, porting an iPhone app to support iPads should be simple, especially for Facebook. There doesn’t have to be an entirely new experience necessarily, just something better than this:

![](https://cdn-images-1.medium.com/max/800/1*Kgz_fsFbVG7VgBO2gJOx5Q.png)

Instagram on iPad

Apple also decided against including a native calculator app on iPad. They have a perfectly good iPhone calculator app but apparently [Steve Jobs didn’t like how the calculator looked blown up on the iPad](http://www.businessinsider.com/why-isnt-the-ipad-shipping-with-a-calculator-app-steve-jobs-didnt-like-the-way-it-looked-2010-3). So now iPad users have to deal with spammy third-party calculator apps.

There are other calculator apps for the iPad that are slightly better, but from the popular ones that I’ve seen, they’re all monetized in one way or another. Banner ads and pop-ups are popular and some have in-app-purchases (IAP) for more functionality.

> Calculator apps should not have pop-up ads

Apps for iOS tend to be more heavily monetized when compared to Android apps. That may have to do with Apple charging $100+ a year compared to the flat $30 fee charged by Google.

### Your App Won’t Make Any Money

Your app revenue won’t allow you to retire early.

Your app revenue won’t allow you to quit your 9–5 and work on your project full time.

Your app revenue won’t justify a few hours a week in maintenance.

Your app revenue won’t be enough to bother remembering your iCloud login.

So if you’re not going to make any money on ads, you may as well open-source your app.

I’m not an expert but I have published 4 apps ([2 iOS games — one with optional ads, the other with ads, 1 iOS](https://itunes.apple.com/us/developer/twelve-31-labs/id997566971?mt=8)/[Android fitness app — free with IAP](https://play.google.com/store/apps/details?id=com.twelve31labs.lujafitness&hl=en)). But I see that there is something terribly wrong with the app store model from a revenue perspective. The main problems are discovery, a saturated market and cost of marketing.

#### Discovery: Why No One Will Download Your App

Apple is considerably worse than Android. I imagine most people search on the App store and just pick one of the top 5 results, based on price and ratings. That’s what I do at least. I’m sure there are iPad calculator apps that are less spammy, but user’s aren’t going to download them if they can’t find them.

Consider the search term “calculator” made on an iPad:

![](https://cdn-images-1.medium.com/max/800/1*MWqE-k9X08hCIJsg0BlIoQ.png)

Top-2 pages of calculator apps on iOS

I haven’t reviewed every top calculator apps, but I did check out a few. _The Calculator_ (top non-ad result) has full screen pop-up ads and a banner ad. Not sure what _The Beautify of Science_ is but it looks like some kind of story. The fourth one _Calculator — Number Systems_ seems like an irregular use-case. _Calculator’_ and _Calculator\*_ are simple and functional enough. But they both have a banner ad and very limited functionality. I mean _very_ limited.

![](https://cdn-images-1.medium.com/max/800/1*F1EtkiGY0DkyafpRzUChcQ.png)

Calculator’

> Aren’t you glad Steve Jobs didn’t want iPad users to experience an ugly blown-up version of the iPhone calculator?

To be fair, _Calculator+_ (top result second page) has no ads and is probably my favorite calculator app. But it’s missing a few features I would like.

I don’t expect free great apps but the top results are especially spammy. And a calculator app is a relatively simple app that is sometimes [used as a tutorial in learning app development.](https://itunes.apple.com/us/course/developing-ios-8-apps-with-swift/id961180099) Maybe less spammy free calculator apps exist, but Apple is failing to funnel users to the best experience.

**A Saturated Market**

There are approximately [2 million apps](https://www.statista.com/statistics/276623/number-of-apps-available-in-leading-app-stores/) on the Apple app store. The Apple app store has been around since 2008. Even assuming a linear growth of apps available, there have been an average of 54 apps released every day. So its understandable that Apple can’t manage that well.

#### Cost of Marketing: Why Your App Won’t Make Any Money

To drive download numbers you can market. I’ve used Facebook and Google AdSense to market and found them effective in terms of reaching your target audience.

At time of writing, if you were to open a Facebook ad campaign optimized for app downloads, $40 would get you an estimated 10–62 app installs. Let’s call it about $1 an app install. This is in line with my experience using Facebook and Google AdSense for a free app. So you have to get at least $1 of value from a download to break even. But consider the following (from 2016):

1.  [Fewer than 25% of users will return to a new app after first use](http://fortune.com/2016/05/19/app-economy/)
2.  [Retention drops to 11% by the first week](http://fortune.com/2016/05/19/app-economy/)
3.  [A full 94% of revenue in the App Store comes from just 1% of all publishers](http://fortune.com/2016/05/19/app-economy/)
4.  [Only about 5% of users are making in-app purchases](https://marketingland.com/app-purchases-dominate-ads-app-store-lifetime-revenue-hits-71-billion-183953)

If you’re using IAP to drive revenue, and 5% of users make in-app-purchases, then your average paid user would have to spend $20 to justify a $1 acquisition cost (1 / 0.05). Apple takes a 30% cut as well so the actual amount is ~$28.5 (1 / 0.05 / 0.7) and the tax man takes his share as well. This is using the generous assumption that a “user” is anyone who downloads your app. And that’s just to break even on what it costs to advertise.

> To justify the $1 cost per acquisition marketing cost, the average paying user must spend over $28.5

How about ad revenue?

Assume that your [average revenue per click is $0.25 and your click-through rate is 1%](https://www.minterest.com/how-much-traffic-do-you-need-to-make-money/). Also, remember that retention rate is only 11% by the first week. Then the number of impressions you would have to make per user to justify a $1 user acquisition is ~3,600 (1 / (0.11 \* 0.25 \* 0.01)). You can have pop-ups or videos that probably pay more, but the numbers would still be unrealistic.

> Each regular user would have to see 3,600 banner ads to justify a $1 cost of acquisition

You can also generate original content via social networks and try to market more organically, but I’m not convinced that’s any cheaper when considering the time investment and luck required. The online advertising business is mature and impressions/influence are fairly priced.

Finally, you can pay for downloads and drive your numbers that way. I’m not too familiar with the overall market, but ethical concerns aside, it is likely a cat-and-mouse game with Apple and Google that is risky over the long-term. I could be wrong though.

> To paraphrase Yogi Berra, nobody publishes apps anymore. It’s too crowded

### How is this Sustainable?

I’m not sure that it is. Marketing and micro-targeting have been getting much better, which is driving advertising effectiveness. But at the same time, businesses may not be critical enough to see whether their marketing is actually economically effective. Large global brands may get a lot of ancillary benefits from the marketing as well that smaller organizations wouldn’t get. The only app developers I know that make any money are those that are paid to build apps for other people.

### Creating Simple Non-Spammy Universal Apps

I would like to contribute to a series of non-monetized open source apps. Its possible that many truly free apps exist and I just cannot find them. In that case, my efforts to create simple free apps won’t make an impact. But it’s worth trying.

I have a number of things that I would like to add to OpenCalc, but I’m going to move on to other apps. If anyone would like to contribute, here are my thoughts on additions, in order of importance:

1.  Break out copy-paste to be accessible by touching the text. Use the extra two buttons to add support for degrees and radians and inverse geometric functions
2.  Support split-screen on Android (font size needs to adjust better for response and buttons)
3.  History
4.  Settings (pretty much anything in the Configs file as well as font sizes)
5.  Different color schemes
6.  Animations
7.  Refactor everything

Pull requests are welcome.

### Future Apps

A list of future apps I would like to build

1.  Financial calculator similar to [BA II Plus calculator](https://education.ti.com/en/products/calculators/financial-calculators/baii-plus). An [app](https://itunes.apple.com/us/app/ba-ii-plus-tm-financial-calculator/id329739750?mt=8) already exists but is expensive ($15)
2.  A simple microphone recording app
3.  A single player Go app
4.  A weather app for iPad

Suggestions are welcome.

By [Branko Blagojevic](https://medium.com/@branko.blagojevic) on [June 28, 2018](https://medium.com/p/41eb5bd30d0e).

[Canonical link](https://medium.com/@branko.blagojevic/a-free-open-source-ipad-calculator-and-why-your-app-wont-make-you-any-money-41eb5bd30d0e)

Exported from [Medium](https://medium.com) on February 27, 2019.